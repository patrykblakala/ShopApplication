package com.patryk.shop.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.patryk.shop.domain.dao.Role;
import com.patryk.shop.domain.dao.User;
import com.patryk.shop.repository.RoleRepository;
import com.patryk.shop.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Set;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.yml")
//@ActiveProfiles("test")
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;


//    @Test
    @Transactional
    void shouldGetUserById() throws Exception {

        Set<Role> roles = new HashSet<>();
        Role role = new Role();
        role.setName("ADMIN");
        roleRepository.save(role);
        roles.add(role);


        User user = userRepository.save(User.builder()
                .email("email@com")
                .password("password")
//                .createdDate(LocalDateTime.of(2020, 1, 1, 12, 0))
//                .lastModifiedDate(LocalDateTime.of(2021, 1, 1, 12, 0))
                .roles(roles)
                .build());

        mockMvc.perform(get("/api/users" + user.getId()))
                .andExpect(status().isOk());
    }
}
