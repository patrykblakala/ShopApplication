package com.patryk.shop.service.impl

import com.patryk.shop.domain.dao.Product
import com.patryk.shop.repository.ProductRepository
import spock.lang.Specification

class ProductServiceImplSpec extends Specification {
    def productService
    def productRepository = Mock(ProductRepository)

    def setup() {
        productService = new ProductServiceImpl(productRepository)
    }

    def 'testing save method'() {
        given;
        Product product = createMock(Poduct)

        when;
        productService.save(product)

        then;
        1 * productRepository.save(product)
        0 * _
    }
}
