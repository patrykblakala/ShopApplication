package com.patryk.shop.service.impl

import spock.lang.Specification

class LoginServiceImplSpec extends Specification{
}
