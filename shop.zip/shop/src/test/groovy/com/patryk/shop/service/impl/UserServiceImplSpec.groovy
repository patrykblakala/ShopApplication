package com.patryk.shop.service.impl

import com.patryk.shop.domain.dao.Role
import com.patryk.shop.domain.dao.User
import com.patryk.shop.repository.RoleRepository
import com.patryk.shop.repository.UserRepository
import org.springframework.security.core.Authentication
import org.springframework.security.core.context.SecurityContext
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.crypto.password.PasswordEncoder
import spock.lang.Specification

import javax.persistence.EntityNotFoundException

class UserServiceImplSpec extends Specification{
    def userService
    def userRepository = Mock(UserRepository)
    def roleRepository = Mock(RoleRepository)
    def passwordEncoder = Mock(PasswordEncoder)

    def setup() {
        userService = new UserServiceImpl(userRepository, roleRepository, passwordEncoder)
    }

    def 'testing save method'() {
        given:
        Role role = new Role(name: "ROLE_USER")
        User user = Mock(User)
        user.setPassword("password")
        Set<Role> roles = new HashSet<>()
        roles.add(role)

        when:
        userService.save(user)

        then:
        1 * roleRepository.findByName("ROLE_USER") >> Optional.of(role)
        1 * user.setRoles(roles)
        1 * user.getPassword() >> "password"
        1 * user.setPassword(_)
        1 * passwordEncoder.encode(_)
        1 * userRepository.save(user)
        0 * _
    }

    def 'testing getById method, should find user by the id'() {
        given:
        User user = Mock(User)
        user.setId(1L)

        when:
        userService.getById(1L)

        then:
        1 * userRepository.findById(1L) >> Optional.of(user)
        0 * _
    }

    def 'testing getById method, should throw an exception'() {
        given:
        User user = Mock(User)
        user.setId(1L)
        userRepository.findById(2L) >> {throw new EntityNotFoundException()}

        when:
        userService.getById(2L)

        then:
        thrown EntityNotFoundException
    }

    def 'testing getCurrentUser method, should get the user'() {
        given:
        User user = Mock(User)
        user.setEmail("email@com")
        SecurityContext securityContext = Mock(SecurityContext)
        SecurityContextHolder.setContext(securityContext)

        Authentication authentication = Mock(Authentication)

        when:
        userService.getCurrentUser()

        then:
        1 * securityContext.getAuthentication() >> authentication
        1 * authentication.getName() >> "email@com"
        1 * userRepository.findByEmail("email@com") >> Optional.of(user)
        0 * _
    }

    def 'testing getByEmail method, should get user'() {
        given:
        User user = Mock(User)
        user.setEmail("email@com")

        when:
        userService.getByEmail("email@com")

        then:
        1 * userRepository.findByEmail("email@com") >> Optional.of(user)
        0 * _
    }

    def 'testing getByEmail method for throwing an Exception'() {
        given:
        User user = Mock(User)
        user.setEmail("email@com")
        userRepository.findByEmail("email108@com") >> {throw new EntityNotFoundException() }

        when:
        userService.getByEmail("email108@com")

        then:
        thrown EntityNotFoundException
    }
}
