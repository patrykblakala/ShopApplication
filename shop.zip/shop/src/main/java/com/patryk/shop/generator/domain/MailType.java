package com.patryk.shop.generator.domain;

public enum MailType {
    IMPORTANT, SPAM, PROMOTIONAL, STARRED;
}
