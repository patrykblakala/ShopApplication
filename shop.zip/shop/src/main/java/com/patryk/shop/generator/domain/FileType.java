package com.patryk.shop.generator.domain;

public enum FileType {
    XLS, PDF, DOC, JSON, CSV;
}
