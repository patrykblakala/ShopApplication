package com.patryk.shop.controller;

import com.patryk.shop.domain.dto.UserDto;
import com.patryk.shop.mapper.UserMapper;
import com.patryk.shop.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {


    private final UserService userService;
    private final UserMapper userMapper;

    @GetMapping("/{id}")
    @Operation(security = {
            @SecurityRequirement(name = "BasicAuth"),
            @SecurityRequirement(name = "bearer-key")
    })

    @PreAuthorize("isAuthenticated()")
    public UserDto getUserById(@PathVariable Long id) {
        return userMapper.userDaoToUserDto(userService.getById(id));
    }

    @PostMapping()
    public UserDto addUser(@RequestBody @Valid UserDto userDto) {
        return userMapper.userDaoToUserDto(userService.save(userMapper.userDtoToUser(userDto)));
    }

}
