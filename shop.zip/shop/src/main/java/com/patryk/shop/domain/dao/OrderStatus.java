package com.patryk.shop.domain.dao;

public enum OrderStatus {
    CREATED, IN_PROGRESS, COMPLETED;
}
