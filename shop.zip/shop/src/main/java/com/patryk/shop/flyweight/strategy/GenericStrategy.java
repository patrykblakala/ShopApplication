package com.patryk.shop.flyweight.strategy;

public interface GenericStrategy<T> {
    T getType();
}
