package com.patryk.shop.service;

import com.patryk.shop.domain.dao.User;

public interface UserService {
    User save(User user);

    User getById(Long id);

    User getCurrentUser();

    User getByEmail(String email);

}
